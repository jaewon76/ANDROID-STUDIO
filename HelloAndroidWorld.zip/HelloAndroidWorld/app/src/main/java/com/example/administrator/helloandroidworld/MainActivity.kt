package com.example.administrator.helloandroidworld

import android.app.Activity
import android.os.Bundle
/* Activity: application component that provides a screen where users can interact to do things */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
